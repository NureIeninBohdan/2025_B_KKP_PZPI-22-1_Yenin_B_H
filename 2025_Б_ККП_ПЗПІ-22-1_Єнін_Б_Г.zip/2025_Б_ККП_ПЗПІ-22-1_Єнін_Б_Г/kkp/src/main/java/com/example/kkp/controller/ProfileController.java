package com.example.kkp.controller;

import com.example.kkp.model.Book;
import com.example.kkp.model.User;
import com.example.kkp.service.CustomUserDetails;
import com.example.kkp.service.RatingService;
import com.example.kkp.service.ReadingStatusService;
import com.example.kkp.service.UserService;
import com.example.kkp.service.BookFilterService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.io.IOException;
import java.nio.file.*;
import java.security.Principal;
import java.util.*;

@Controller
public class ProfileController {

    private final ReadingStatusService readingStatusService;
    private final RatingService ratingService;
    private final UserService userService;
    private final BookFilterService bookFilterService;

    public ProfileController(ReadingStatusService readingStatusService,
                             RatingService ratingService,
                             UserService userService,
                             BookFilterService bookFilterService) {
        this.readingStatusService = readingStatusService;
        this.ratingService = ratingService;
        this.userService = userService;
        this.bookFilterService = bookFilterService;
    }



    @GetMapping("/profile")
    public String showProfile(@AuthenticationPrincipal CustomUserDetails currentUser,
                              @RequestParam(name = "avatarUpdated", required = false) Long avatarUpdated,
                              @RequestParam(name = "status", required = false, defaultValue = "all") String status,
                              @RequestParam(name = "page", required = false, defaultValue = "0") int page,
                              @RequestParam(name = "size", required = false, defaultValue = "20") int size,
                              Model model) {
        if (currentUser == null) return "redirect:/login";
        Long userId = currentUser.getId();

        List<Book> readingBooks = readingStatusService.findBooksByUserAndStatus(userId, "Читаю");
        List<Book> plannedBooks = readingStatusService.findBooksByUserAndStatus(userId, "В планах");
        List<Book> readBooks    = readingStatusService.findBooksByUserAndStatus(userId, "Прочитано");

        Map<Long, Integer> userRatings = ratingService.findRatingsByUser(userId);

        List<Book> displayedBooks = combinedBooks(readingBooks, plannedBooks, readBooks, userId, status, userRatings);

        sortByRating(readingBooks, userRatings);
        sortByRating(plannedBooks, userRatings);
        sortByRating(readBooks, userRatings);
        sortByRating(displayedBooks, userRatings);

        Page<Book> pageObj = toPage(displayedBooks, page, size);

        Double averageUserRating = userRatings.isEmpty() ? null :
                Math.round(userRatings.values().stream().mapToInt(Integer::intValue).average().orElse(0.0) * 100.0) / 100.0;

        model.addAttribute("user", currentUser.getUser());
        model.addAttribute("readingBooks", readingBooks);
        model.addAttribute("plannedBooks", plannedBooks);
        model.addAttribute("readBooks", readBooks);
        model.addAttribute("allBooks", displayedBooks);
        model.addAttribute("page", pageObj);
        model.addAttribute("books", pageObj.getContent());
        model.addAttribute("size", size);
        model.addAttribute("bookStatuses", readingStatusService.findStatusesByUser(userId));
        model.addAttribute("userRatings", userRatings);
        model.addAttribute("averageUserRating", averageUserRating);
        model.addAttribute("cacheBuster", avatarUpdated != null ? avatarUpdated : System.currentTimeMillis());
        model.addAttribute("isAuthenticated", true);
        model.addAttribute("isOwner", true);
        model.addAttribute("status", status);

        return "profile";
    }

    @GetMapping("/profile/{username}")
    public String viewUserProfile(@PathVariable String username,
                                  @RequestParam(name = "status", required = false, defaultValue = "all") String status,
                                  @RequestParam(name = "page", required = false, defaultValue = "0") int page,
                                  @RequestParam(name = "size", required = false, defaultValue = "20") int size,
                                  Model model) {
        User user = userService.findByUsername(username);
        Long userId = user.getUserId().longValue();

        List<Book> readingBooks = readingStatusService.findBooksByUserAndStatus(userId, "Читаю");
        List<Book> plannedBooks = readingStatusService.findBooksByUserAndStatus(userId, "В планах");
        List<Book> readBooks    = readingStatusService.findBooksByUserAndStatus(userId, "Прочитано");

        Map<Long, Integer> userRatings = ratingService.findRatingsByUser(userId);

        List<Book> displayedBooks = combinedBooks(readingBooks, plannedBooks, readBooks, userId, status, userRatings);

        sortByRating(readingBooks, userRatings);
        sortByRating(plannedBooks, userRatings);
        sortByRating(readBooks, userRatings);
        sortByRating(displayedBooks, userRatings);

        Page<Book> pageObj = toPage(displayedBooks, page, size);

        Double averageUserRating = userRatings.isEmpty() ? null :
                Math.round(userRatings.values().stream().mapToInt(Integer::intValue).average().orElse(0.0) * 100.0) / 100.0;

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean isAuthenticated = authentication != null &&
                authentication.isAuthenticated() &&
                !(authentication.getPrincipal() instanceof String);

        boolean isOwner = false;
        if (isAuthenticated && authentication.getPrincipal() instanceof CustomUserDetails cud) {
            isOwner = cud.getUsername().equals(username);
        }

        model.addAttribute("user", user);
        model.addAttribute("readingBooks", readingBooks);
        model.addAttribute("plannedBooks", plannedBooks);
        model.addAttribute("readBooks", readBooks);
        model.addAttribute("allBooks", displayedBooks);
        model.addAttribute("page", pageObj);
        model.addAttribute("books", pageObj.getContent());
        model.addAttribute("size", size);
        model.addAttribute("bookStatuses", readingStatusService.findStatusesByUser(userId));
        model.addAttribute("userRatings", userRatings);
        model.addAttribute("averageUserRating", averageUserRating);
        model.addAttribute("cacheBuster", System.currentTimeMillis());
        model.addAttribute("isAuthenticated", isAuthenticated);
        model.addAttribute("isOwner", isOwner);
        model.addAttribute("status", status);

        return "profile";
    }


    private List<Book> combinedBooks(List<Book> reading, List<Book> planned, List<Book> read,
                                     Long userId, String status, Map<Long, Integer> userRatings) {
        if (!"all".equalsIgnoreCase(status)) {
            return switch (status) {
                case "Читаю" -> new ArrayList<>(reading);
                case "В планах" -> new ArrayList<>(planned);
                case "Прочитано" -> new ArrayList<>(read);
                default -> {
                    Set<Book> s = new LinkedHashSet<>();
                    s.addAll(reading); s.addAll(planned); s.addAll(read);
                    yield new ArrayList<>(s);
                }
            };
        }
        Set<Book> all = new LinkedHashSet<>();
        all.addAll(reading); all.addAll(planned); all.addAll(read);

        for (Long bookId : userRatings.keySet()) {
            boolean exists = all.stream().anyMatch(b -> b.getBookId().equals(bookId));
            if (!exists) {
                readingStatusService.findBookById(bookId).ifPresent(all::add);
            }
        }
        return new ArrayList<>(all);
    }

    private void sortByRating(List<Book> books, Map<Long, Integer> userRatings) {
        Comparator<Book> byTitle = Comparator.comparing(
                Book::getTitle,
                Comparator.nullsLast(String.CASE_INSENSITIVE_ORDER)
        );
        Comparator<Book> byId = Comparator.comparing(Book::getBookId, Comparator.nullsLast(Long::compareTo));

        Comparator<Book> byUserRatingDesc = Comparator
                .comparingInt((Book b) -> userRatings.getOrDefault(b.getBookId(), 0))
                .reversed()
                .thenComparing(byTitle)
                .thenComparing(byId);

        books.sort(byUserRatingDesc);
    }

    private Page<Book> toPage(List<Book> items, int page, int size) {
        if (size <= 0) size = 20;
        if (page < 0) page = 0;
        int total = items == null ? 0 : items.size();
        int from = Math.min(page * size, total);
        int to   = Math.min(from + size, total);
        List<Book> content = (from < to) ? items.subList(from, to) : Collections.emptyList();
        return new PageImpl<>(content, PageRequest.of(page, size), total);
    }

    @PostMapping("/profile/upload-avatar")
    public String uploadAvatar(@RequestParam("avatar") MultipartFile file,
                               Principal principal,
                               RedirectAttributes redirectAttributes) {
        try {
            if (file.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "Файл не вибрано");
                return "redirect:/profile";
            }

            String contentType = file.getContentType();
            if (contentType == null || !contentType.startsWith("image/")) {
                redirectAttributes.addFlashAttribute("error", "Можна завантажувати лише зображення");
                return "redirect:/profile";
            }

            User user = userService.findByUsername(principal.getName());

            Path uploadDir = Paths.get("uploads/avatars");
            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }

            if (user.getAvatarPath() != null) {
                String oldAvatarFileName = Paths.get(user.getAvatarPath()).getFileName().toString();
                if (!oldAvatarFileName.equalsIgnoreCase("No Avatar.jpeg")) {
                    Path oldAvatarPath = uploadDir.resolve(oldAvatarFileName);
                    Files.deleteIfExists(oldAvatarPath);
                }
            }

            String originalFileName = file.getOriginalFilename();
            if ("No Avatar.jpeg".equalsIgnoreCase(originalFileName)) {
                String extension = originalFileName.substring(originalFileName.lastIndexOf('.'));
                originalFileName = "avatar_" + UUID.randomUUID() + extension;
            }

            String fileName = UUID.randomUUID() + "_" + originalFileName;
            Path filePath = uploadDir.resolve(fileName);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            user.setAvatarPath("/uploads/avatars/" + fileName);
            userService.save(user);

            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
                CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
                userDetails.setUser(user);
                UsernamePasswordAuthenticationToken newAuth = new UsernamePasswordAuthenticationToken(
                        userDetails, auth.getCredentials(), userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(newAuth);
            }

            redirectAttributes.addFlashAttribute("success", "Аватар оновлено");
        } catch (IOException e) {
            redirectAttributes.addFlashAttribute("error", "Помилка при завантаженні файлу");
            e.printStackTrace();
        }

        return "redirect:/profile";
    }

    @PostMapping("/profile/delete-avatar")
    public String deleteAvatar(Principal principal, RedirectAttributes redirectAttributes) {
        try {
            if (principal == null) {
                redirectAttributes.addFlashAttribute("error", "Неавторизований доступ");
                return "redirect:/login";
            }

            User user = userService.findByUsername(principal.getName());

            if (user.getAvatarPath() != null && !user.getAvatarPath().endsWith("No Avatar.jpeg")) {
                Path uploadDir = Paths.get("uploads/avatars");
                String avatarFileName = Paths.get(user.getAvatarPath()).getFileName().toString();
                Path avatarPath = uploadDir.resolve(avatarFileName);
                Files.deleteIfExists(avatarPath);

                user.setAvatarPath("/uploads/avatars/No Avatar.jpeg");
                userService.save(user);

                Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                if (auth != null && auth.getPrincipal() instanceof CustomUserDetails) {
                    CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
                    userDetails.setUser(user);
                    UsernamePasswordAuthenticationToken newAuth = new UsernamePasswordAuthenticationToken(
                            userDetails, auth.getCredentials(), userDetails.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(newAuth);
                }

                redirectAttributes.addFlashAttribute("success", "Аватар видалено");
            } else {
                redirectAttributes.addFlashAttribute("info", "Аватар відсутній або вже дефолтний");
            }
        } catch (IOException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Помилка при видаленні аватара");
        }
        return "redirect:/profile";
    }

}
