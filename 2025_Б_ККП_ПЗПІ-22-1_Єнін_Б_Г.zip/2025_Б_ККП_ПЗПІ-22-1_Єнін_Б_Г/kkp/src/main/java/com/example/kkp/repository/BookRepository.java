package com.example.kkp.repository;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.kkp.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

    boolean existsByOpenLibraryId(String openLibraryId);

    List<Book> findByTitleContainingIgnoreCase(String title);

    List<Book> findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(String title, String author);

    Page<Book> findAll(Pageable pageable);

    @Query("""
    SELECT b FROM Book b
    WHERE (:query IS NULL OR LOWER(b.title) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(b.author) LIKE LOWER(CONCAT('%', :query, '%')))
""")
    Page<Book> searchBooks(@Param("query") String query, Pageable pageable);


    @Query("SELECT b.openLibraryId FROM Book b")
    List<String> findAllOpenLibraryIds();
}