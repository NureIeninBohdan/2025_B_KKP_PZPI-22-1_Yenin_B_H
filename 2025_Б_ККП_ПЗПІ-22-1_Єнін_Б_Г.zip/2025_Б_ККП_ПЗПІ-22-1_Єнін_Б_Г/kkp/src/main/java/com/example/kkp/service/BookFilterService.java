package com.example.kkp.service;

import com.example.kkp.model.Book;
import com.example.kkp.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BookFilterService {

    private final BookRepository bookRepository;
    private final RatingService ratingService;
    private final ReadingStatusService readingStatusService;

    public BookFilterService(BookRepository bookRepository,
                             RatingService ratingService,
                             ReadingStatusService readingStatusService) {
        this.bookRepository = bookRepository;
        this.ratingService = ratingService;
        this.readingStatusService = readingStatusService;
    }


    public Page<Book> getBooks(String query, String sortType, Long userId, int page, int size) {
        boolean hasQuery = query != null && !query.trim().isEmpty();

        Sort sort = switch (sortType == null ? "" : sortType.toLowerCase()) {
            case "rating"     -> Sort.by(Sort.Order.desc("averageRating"));
            case "popularity" -> Sort.by(Sort.Order.desc("popularity"));
            default           -> Sort.by(Sort.Order.asc("title").ignoreCase());
        };

        Pageable pageable = PageRequest.of(page, size, sort);

        return hasQuery
                ? bookRepository.searchBooks(query.trim(), pageable)
                : bookRepository.findAll(pageable);
    }



}
