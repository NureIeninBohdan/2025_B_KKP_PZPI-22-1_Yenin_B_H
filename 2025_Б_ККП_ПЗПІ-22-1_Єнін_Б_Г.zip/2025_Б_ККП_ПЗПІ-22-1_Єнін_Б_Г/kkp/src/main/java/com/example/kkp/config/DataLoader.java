package com.example.kkp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import com.example.kkp.service.BookImportService;

/*@Component
@ConditionalOnProperty(name = "import.enabled", havingValue = "true", matchIfMissing = false)
public class DataLoader implements CommandLineRunner {

    private final BookImportService bookImportService;
    private final Long limit;

    public DataLoader(
            BookImportService bookImportService,
            @Value("${import.limit:#{null}}") Long limit
    ) {
        this.bookImportService = bookImportService;
        this.limit = limit;
    }

    @Override
    public void run(String... args) {
        if (limit != null && limit > 0) {
            bookImportService.importBooksOnce(limit);
            bookImportService.importBooksOnce();
        }
    }
}*/
