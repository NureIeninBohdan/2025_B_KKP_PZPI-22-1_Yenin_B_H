package com.example.kkp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.kkp.service.UserService;
import com.example.kkp.service.EmailService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class    EmailController {

    private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;

    @GetMapping("/password-recovery")
    public String showRecoveryForm() {
        return "password-recovery";
    }

    @PostMapping("/password-recovery")
    public String handleRecovery(@RequestParam String email, Model model) {
        logger.info("Отримано запит на відновлення паролю для email: {}", email);

        if (!userService.existsByEmail(email)) {
            logger.warn("Користувач з email {} не знайдений", email);
            model.addAttribute("errorMessage", "Користувача з таким email не знайдено.");
            return "password-recovery";
        }

        String token = userService.createPasswordResetToken(email);
        logger.info("Створено токен для відновлення паролю: {}", token);

        String resetLink = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/reset-password")
                .queryParam("token", token)
                .toUriString();
        logger.info("Посилання для скидання паролю: {}", resetLink);

        String content = "Щоб скинути пароль, перейдіть за посиланням: " + resetLink;
        boolean mailSent = emailService.sendEmail(email, "Відновлення паролю", content);

        if (!mailSent) {
            logger.error("Не вдалося відправити лист на email {}", email);
            model.addAttribute("errorMessage", "Не вдалося відправити лист. Спробуйте пізніше.");
            return "password-recovery";
        }

        logger.info("Лист для відновлення паролю успішно відправлено на {}", email);
        model.addAttribute("successMessage", "Лист для відновлення паролю відправлено.");
        return "password-recovery";
    }
}
