package com.example.kkp.controller;

import com.example.kkp.model.Book;
import com.example.kkp.repository.BookRepository;
import com.example.kkp.service.BookFilterService;
import com.example.kkp.service.CommentService;
import com.example.kkp.service.CustomUserDetails;
import com.example.kkp.service.RatingService;
import com.example.kkp.service.ReadingStatusService;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

@Controller
public class BookController {

    private final BookFilterService bookFilterService;
    private final ReadingStatusService readingStatusService;
    private final RatingService ratingService;
    private final BookRepository bookRepository;
    private final CommentService commentService;

    private static final String NO_COVER_PATH = "/uploads/covers/No Cover.jpg";

    public BookController(BookFilterService bookFilterService,
                          ReadingStatusService readingStatusService,
                          RatingService ratingService,
                          BookRepository bookRepository,
                          CommentService commentService) {
        this.bookRepository = bookRepository;
        this.bookFilterService = bookFilterService;
        this.readingStatusService = readingStatusService;
        this.ratingService = ratingService;
        this.commentService = commentService;
    }

    @GetMapping("/")
    public String showHomePage(@AuthenticationPrincipal CustomUserDetails currentUser,
                               @RequestParam(value = "search", required = false) String search,
                               @RequestParam(value = "sort", required = false) String sort,
                               @RequestParam(value = "page", defaultValue = "0") int page,
                               @RequestParam(value = "size", defaultValue = "24") int size,
                               Model model) {

        Long userId = (currentUser != null) ? currentUser.getId() : null;

        Page<Book> booksPage = bookFilterService.getBooks(search, sort, userId, page, size);

        booksPage.getContent().forEach(book -> {
            if (book.getCoverUrl() == null || book.getCoverUrl().isEmpty()) {
                book.setCoverUrl(NO_COVER_PATH);
            }
            Double avgRating = book.getAverageRating();
            if (avgRating == null) avgRating = 0.0;
            book.setAverageRating(Math.round(avgRating * 100.0) / 100.0);
        });

        model.addAttribute("books", booksPage.getContent());
        model.addAttribute("page", booksPage);
        model.addAttribute("isLoggedIn", currentUser != null);
        model.addAttribute("sort", sort == null ? "" : sort);
        model.addAttribute("search", search == null ? "" : search);

        return "index";
    }

    @GetMapping("/books/{id}")
    public String showBookDetails(@PathVariable Long id,
                                  @AuthenticationPrincipal CustomUserDetails currentUser,
                                  Model model) {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        if (book.getCoverUrl() == null || book.getCoverUrl().isEmpty()) {
            book.setCoverUrl(NO_COVER_PATH);
        }

        Double avgRating = book.getAverageRating();
        if (avgRating == null) avgRating = 0.0;
        book.setAverageRating(Math.round(avgRating * 100.0) / 100.0);

        model.addAttribute("book", book);
        model.addAttribute("isLoggedIn", currentUser != null);

        Long currentUserId = null;
        boolean isAdmin = false;
        if (currentUser != null) {
            currentUserId = currentUser.getId();
            isAdmin = currentUser.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ADMIN"));

            String status = readingStatusService.findStatusByUserAndBook(currentUserId, id).orElse("Не вибрано");
            model.addAttribute("userStatus", status);

            Integer rating = ratingService.findRatingByUserAndBook(currentUserId, id).orElse(null);
            model.addAttribute("userRating", rating);
        }

        long readCount = readingStatusService.countByBookIdAndStatus(id, "Прочитано");
        long readingCount = readingStatusService.countByBookIdAndStatus(id, "Читаю");
        long plannedCount = readingStatusService.countByBookIdAndStatus(id, "В планах");

        model.addAttribute("readCount", readCount);
        model.addAttribute("readingCount", readingCount);
        model.addAttribute("plannedCount", plannedCount);

        model.addAttribute("comments", commentService.getCommentsForBook(id, currentUserId, isAdmin));

        return "book";
    }
}
