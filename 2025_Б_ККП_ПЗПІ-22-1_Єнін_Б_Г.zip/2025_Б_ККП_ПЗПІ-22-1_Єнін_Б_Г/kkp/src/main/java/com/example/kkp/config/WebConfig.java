package com.example.kkp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        Path avatarUploadDir = Paths.get("uploads/avatars");
        String avatarUploadPath = avatarUploadDir.toFile().getAbsolutePath();

        registry.addResourceHandler("/uploads/avatars/**")
                .addResourceLocations("file:" + avatarUploadPath + "/");

        Path coverUploadDir = Paths.get("uploads/covers");
        String coverUploadPath = coverUploadDir.toFile().getAbsolutePath();

        registry.addResourceHandler("/uploads/covers/**")
                .addResourceLocations("file:" + coverUploadPath + "/");

        Path iconsUploadDir = Paths.get("uploads/icons");
        String iconsUploadPath = iconsUploadDir.toFile().getAbsolutePath();

        registry.addResourceHandler("/uploads/icons/**")
                .addResourceLocations("file:" + iconsUploadPath + "/");
    }
}
