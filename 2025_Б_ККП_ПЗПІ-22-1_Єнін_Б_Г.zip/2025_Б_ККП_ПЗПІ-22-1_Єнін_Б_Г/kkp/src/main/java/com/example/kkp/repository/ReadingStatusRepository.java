package com.example.kkp.repository;

import com.example.kkp.model.ReadingStatus;
import com.example.kkp.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Set;
import java.util.Optional;
import java.util.List;

public interface ReadingStatusRepository extends JpaRepository<ReadingStatus, Long> {
    Optional<ReadingStatus> findByUserIdAndBookId(Long userId, Long bookId);

    List<ReadingStatus> findAllByUserIdAndStatus(Long userId, String status);

    List<ReadingStatus> findAllByUserId(Long userId);

    long countByBookIdAndStatus(Long bookId, String status);

    @Transactional
    void deleteByBookId(Long bookId);

    @Query("SELECT DISTINCT rs.userId FROM ReadingStatus rs WHERE rs.bookId = :bookId")
    Set<Long> findUserIdsByBookId(@Param("bookId") Long bookId);

    @Query("SELECT rs.book FROM ReadingStatus rs WHERE rs.userId = :userId AND rs.status = :status")
    List<Book> findBooksByUserIdAndStatus(@Param("userId") Long userId, @Param("status") String status);

}
