package com.example.kkp.repository;

import com.example.kkp.model.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.List;
import java.util.Set;

public interface RatingRepository extends JpaRepository<Rating, Long> {
    Optional<Rating> findByUserIdAndBookId(Long userId, Long bookId);
    List<Rating> findByBookId(Long bookId);
    List<Rating> findAllByUserId(Long userId);

    @Transactional
    void deleteByBookId(Long bookId);

    long countByBookId(Long bookId);

    @Query("SELECT DISTINCT r.userId FROM Rating r WHERE r.bookId = :bookId")
    Set<Long> findUserIdsByBookId(@Param("bookId") Long bookId);

    @Query("SELECT AVG(r.rating) FROM Rating r WHERE r.bookId = :bookId")
    Double calculateAverageRating(@Param("bookId") Long bookId);
}
