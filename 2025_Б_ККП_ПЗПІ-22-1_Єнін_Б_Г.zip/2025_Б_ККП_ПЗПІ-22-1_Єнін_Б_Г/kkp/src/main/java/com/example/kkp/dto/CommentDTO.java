package com.example.kkp.dto;

public class CommentDTO {
    private Long commentId;
    private String comment;
    private String sentAt;
    private String username;
    private String authorDisplayName;
    private boolean canDelete;
    private String avatarUrl;

    public CommentDTO() {
    }

    public CommentDTO(Long commentId, String comment, String sentAt,
                      String username, String authorDisplayName, boolean canDelete) {
        this(commentId, comment, sentAt, username, authorDisplayName, canDelete, null);
    }

    public CommentDTO(Long commentId, String comment, String sentAt,
                      String username, String authorDisplayName, boolean canDelete,
                      String avatarUrl) {
        this.commentId = commentId;
        this.comment = comment;
        this.sentAt = sentAt;
        this.username = username;
        this.authorDisplayName = authorDisplayName;
        this.canDelete = canDelete;
        this.avatarUrl = avatarUrl;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getSentAt() {
        return sentAt;
    }

    public void setSentAt(String sentAt) {
        this.sentAt = sentAt;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAuthorDisplayName() {
        return authorDisplayName;
    }

    public void setAuthorDisplayName(String authorDisplayName) {
        this.authorDisplayName = authorDisplayName;
    }

    public boolean isCanDelete() {
        return canDelete;
    }

    public void setCanDelete(boolean canDelete) {
        this.canDelete = canDelete;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }
}
