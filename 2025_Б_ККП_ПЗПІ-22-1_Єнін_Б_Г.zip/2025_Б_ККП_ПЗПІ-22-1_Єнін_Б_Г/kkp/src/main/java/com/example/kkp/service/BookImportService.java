package com.example.kkp.service;

import com.example.kkp.model.Book;
import com.example.kkp.dto.BookDTO;
import com.example.kkp.repository.BookRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonParser;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.beans.factory.annotation.Value;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.stream.StreamSupport;
import java.util.zip.GZIPInputStream;

@Service
public class BookImportService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper()
            .configure(JsonParser.Feature.ALLOW_COMMENTS, true)
            .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
            .configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);

    private final BookRepository bookRepository;

    @Value("${openlibrary.worksDumpPath:}")
    private String worksDumpPath;

    @Value("${openlibrary.authorsDumpPath:}")
    private String authorsDumpPath;

    @Value("${openlibrary.editionsDumpPath:}")
    private String editionsDumpPath;

    @Value("${import.limit:200}")
    private long importLimit;

    private static final String DEFAULT_COVER_URL = "/uploads/covers/No Cover.jpg";
    private static final long READ_LINES_LIMIT_PER_DUMP = 400L;

    public BookImportService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    private boolean isLatinOnly(String text) {
        if (text == null) return false;
        String t = text.trim();
        if (t.length() < 3) return false;
        return t.codePoints().allMatch(cp -> {
            if (Character.isWhitespace(cp) || Character.isDigit(cp)) return true;
            Character.UnicodeBlock block = Character.UnicodeBlock.of(cp);
            return block == Character.UnicodeBlock.BASIC_LATIN
                    || block == Character.UnicodeBlock.LATIN_1_SUPPLEMENT
                    || block == Character.UnicodeBlock.LATIN_EXTENDED_A
                    || block == Character.UnicodeBlock.LATIN_EXTENDED_B
                    || block == Character.UnicodeBlock.GENERAL_PUNCTUATION;
        });
    }

    @Async
    public void importBooksOnce() {
        long effectiveLimit = importLimit > 0 ? importLimit : Long.MAX_VALUE;
        doImport(effectiveLimit);
    }

    @Async
    public void importBooksOnce(Long limit) {
        long effectiveLimit = (limit == null || limit <= 0) ? Long.MAX_VALUE : limit;
        doImport(effectiveLimit);
    }

    private void doImport(long effectiveLimit) {
        if (worksDumpPath == null || worksDumpPath.isBlank()) {
            System.out.println("Не задано шлях до дампа works");
            return;
        }

        Map<String, String> authorMap = loadAuthorsMap(authorsDumpPath);

        Set<String> englishWorkIds = loadEnglishWorkKeys(editionsDumpPath);

        try (BufferedReader br = openReader(worksDumpPath)) {
            String line;
            long total = 0, saved = 0;

            while ((line = br.readLine()) != null) {
                total++;
                line = line.trim();
                if (shouldSkipLine(line)) continue;

                String json = extractJsonPart(line);
                if (json == null) continue;

                JsonNode work = objectMapper.readTree(json);
                String workKey = work.path("key").asText("");
                if (workKey.isBlank()
                        || !englishWorkIds.contains(workKey)
                        || bookRepository.existsByOpenLibraryId(workKey)) {
                    continue;
                }

                String title = work.path("title").asText("");
                if (title.isBlank() || !isLatinOnly(title)) continue;

                String authorKey = "";
                JsonNode authorsNode = work.path("authors");
                if (authorsNode.isArray() && authorsNode.size() > 0) {
                    JsonNode firstAuthor = authorsNode.get(0).path("author");
                    authorKey = firstAuthor.isTextual()
                            ? firstAuthor.asText("")
                            : firstAuthor.path("key").asText("");
                }
                String authorName = authorMap.getOrDefault(authorKey, "");

                String description = extractDescription(work.path("description"));
                String coverUrl    = buildCoverUrl(work.path("covers"));

                Book book = new Book();
                book.setOpenLibraryId(workKey);
                book.setTitle(title);
                book.setAuthor(authorName);
                book.setDescription(description);
                book.setCoverUrl(coverUrl);

                bookRepository.save(book);
                if (++saved >= effectiveLimit) break;

                if (total % 10_000 == 0) {
                    System.out.printf("Опрацьовано %,d | Збережено %,d%n", total, saved);
                }
            }

            System.out.printf("Імпорт завершено. Прочитано: %,d | Збережено: %,d%n", total, saved);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Set<String> loadEnglishWorkKeys(String path) {
        Set<String> englishWorkIds = new HashSet<>();
        if (path == null || path.isBlank()) {
            System.out.println("Не задано шлях до дампа editions");
            return englishWorkIds;
        }

        try (BufferedReader br = openReader(path)) {
            String line;
            long read = 0;

            while ((line = br.readLine()) != null && read++ < READ_LINES_LIMIT_PER_DUMP) {
                line = line.trim();
                if (shouldSkipLine(line)) continue;

                String json = extractJsonPart(line);
                if (json == null) continue;

                JsonNode edition = objectMapper.readTree(json);
                JsonNode langs = edition.path("languages");
                boolean isEng = langs.isArray() &&
                        StreamSupport.stream(langs.spliterator(), false)
                                .map(l -> l.path("key").asText(""))
                                .anyMatch("/languages/eng"::equals);
                if (!isEng) continue;

                JsonNode works = edition.path("works");
                if (works.isArray()) {
                    for (JsonNode w : works) {
                        String wk = w.path("key").asText("");
                        if (!wk.isBlank()) englishWorkIds.add(wk);
                    }
                }
            }

            System.out.printf("Знайдено англомовних works: %,d%n", englishWorkIds.size());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return englishWorkIds;
    }

    private Map<String, String> loadAuthorsMap(String path) {
        Map<String, String> map = new HashMap<>();
        if (path == null || path.isBlank()) {
            System.out.println("Шлях до authors dump не вказано — автори будуть порожні");
            return map;
        }

        try (BufferedReader br = openReader(path)) {
            String line;
            long count = 0;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (shouldSkipLine(line)) continue;

                String json = extractJsonPart(line);
                if (json == null) continue;

                JsonNode authorNode = objectMapper.readTree(json);
                String key  = authorNode.path("key").asText("");
                String name = authorNode.path("name").asText("");
                if (name.isBlank()) {
                    name = authorNode.path("personal_name").asText("");
                }
                if (!key.isBlank() && !name.isBlank()) {
                    map.put(key, name);
                    count++;
                }
            }
            System.out.println("Завантажено авторів: " + count);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return map;
    }

    private String extractJsonPart(String line) {
        int i = line.indexOf('{'), j = line.indexOf('[');
        if (i == -1 && j == -1) return null;
        int start = i == -1 ? j : (j == -1 ? i : Math.min(i, j));
        return line.substring(start).trim();
    }

    private BufferedReader openReader(String path) throws IOException {
        InputStream in = Files.newInputStream(Paths.get(path));
        if (path.toLowerCase().endsWith(".gz")) {
            return new BufferedReader(
                    new InputStreamReader(new GZIPInputStream(in), StandardCharsets.UTF_8));
        }
        return new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
    }

    private boolean shouldSkipLine(String line) {
        if (line.isEmpty()) return true;
        if (line.startsWith("//") || line.startsWith("/*") || line.startsWith("#")) return true;
        return line.indexOf('{') < 0 && line.indexOf('[') < 0;
    }

    private String extractDescription(JsonNode descriptionNode) {
        if (descriptionNode == null || descriptionNode.isMissingNode() || descriptionNode.isNull()) {
            return "";
        }
        if (descriptionNode.isTextual()) {
            return descriptionNode.asText();
        }
        JsonNode value = descriptionNode.path("value");
        return value.isTextual() ? value.asText() : "";
    }

    private String buildCoverUrl(JsonNode coversNode) {
        if (coversNode != null && coversNode.isArray() && coversNode.size() > 0) {
            JsonNode first = coversNode.get(0);
            if (first.canConvertToInt()) {
                return "https://covers.openlibrary.org/b/id/"
                        + first.asInt() + "-L.jpg";
            }
        }
        return DEFAULT_COVER_URL;
    }


    public List<BookDTO> searchBooks(String query) {
        try {
            String url = "https://openlibrary.org/search.json?q=" + query + "&language=eng";
            String response = restTemplate.getForObject(url, String.class);

            JsonNode root = objectMapper.readTree(response);
            JsonNode docs = root.path("docs");

            List<BookDTO> results = new ArrayList<>();
            for (JsonNode bookNode : docs) {
                String title = bookNode.path("title").asText();
                if (!isLatinOnly(title)) {
                    continue;
                }

                String author = bookNode.path("author_name").isArray()
                        ? bookNode.path("author_name").get(0).asText()
                        : "";

                String coverUrl = null;
                if (bookNode.has("cover_i")) {
                    int coverId = bookNode.get("cover_i").asInt();
                    coverUrl = "https://covers.openlibrary.org/b/id/" + coverId + "-M.jpg";
                }

                String key = bookNode.path("key").asText();
                String openLibraryId = key.replace("/works/", "");

                BookDTO dto = new BookDTO();
                dto.setTitle(title);
                dto.setAuthor(author);
                dto.setCoverUrl(coverUrl);
                dto.setOpenLibraryId(openLibraryId);
                dto.setKey(key);

                results.add(dto);
            }
            return results;
        } catch (Exception e) {
            e.printStackTrace();
            return java.util.Collections.emptyList();
        }
    }

    public void importBookByOpenLibraryId(String rawId) {
        System.out.println("Отриманий ID: " + rawId);

        try {
            String openLibraryId = rawId.trim().replace("\"", "");
            if (!openLibraryId.startsWith("/works/")) {
                openLibraryId = "/works/" + openLibraryId;
            }

            if (bookRepository.existsByOpenLibraryId(openLibraryId)) {
                System.out.println("Книга з таким OpenLibraryId вже існує: " + openLibraryId);
                throw new RuntimeException("Книга вже існує");
            }

            String workDetailsUrl = "https://openlibrary.org" + openLibraryId + ".json";
            String response = restTemplate.getForObject(workDetailsUrl, String.class);
            JsonNode workDetails = objectMapper.readTree(response);

            String title = workDetails.path("title").asText();
            if (!isLatinOnly(title)) {
                System.out.println("Скасовано імпорт: назва не латиницею — " + title);
                return;
            }

            String author = "";
            if (workDetails.has("authors") && workDetails.get("authors").isArray() && workDetails.get("authors").size() > 0) {
                JsonNode authorRef = workDetails.get("authors").get(0).path("author").path("key");
                if (authorRef != null) {
                    try {
                        String authorKey = authorRef.asText();
                        String authorUrl = "https://openlibrary.org" + authorKey + ".json";
                        String authorResponse = restTemplate.getForObject(authorUrl, String.class);
                        JsonNode authorNode = objectMapper.readTree(authorResponse);
                        author = authorNode.path("name").asText();
                    } catch (Exception ex) {
                        System.out.println("Не вдалося отримати ім'я автора");
                    }
                }
            }

            String description = "";
            JsonNode descriptionNode = workDetails.path("description");
            if (descriptionNode.isTextual()) {
                description = descriptionNode.asText();
            } else if (descriptionNode.has("value")) {
                description = descriptionNode.path("value").asText();
            }

            String coverUrl = null;
            if (workDetails.has("covers") && workDetails.get("covers").isArray() && workDetails.get("covers").size() > 0) {
                int coverId = workDetails.get("covers").get(0).asInt();
                coverUrl = "https://covers.openlibrary.org/b/id/" + coverId + "-L.jpg";
            }

            Book book = new Book();
            book.setTitle(title);
            book.setAuthor(author);
            book.setOpenLibraryId(openLibraryId);
            book.setDescription(description);
            book.setCoverUrl(coverUrl);

            bookRepository.save(book);
            System.out.println("Книга імпортована: " + title);

        } catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            System.out.println("Помилка при імпорті книги з ID: " + rawId);
            e.printStackTrace();
            throw new RuntimeException("Помилка при імпорті книги: " + e.getMessage());
        }
    }

}
