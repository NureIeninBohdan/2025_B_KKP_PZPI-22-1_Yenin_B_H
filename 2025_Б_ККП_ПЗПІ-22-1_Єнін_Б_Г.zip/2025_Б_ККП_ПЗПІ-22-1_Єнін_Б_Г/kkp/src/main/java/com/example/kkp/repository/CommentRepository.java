package com.example.kkp.repository;

import com.example.kkp.model.Comment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByBookIdOrderBySentAtDesc(Long bookId);
}
