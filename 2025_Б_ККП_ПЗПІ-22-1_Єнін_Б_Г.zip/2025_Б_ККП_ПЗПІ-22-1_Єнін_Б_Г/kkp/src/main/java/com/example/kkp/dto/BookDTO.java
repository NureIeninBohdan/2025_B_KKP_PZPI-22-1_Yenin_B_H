package com.example.kkp.dto;

public class BookDTO {
    private String title;
    private String author;
    private String coverUrl;
    private String openLibraryId;
    private String description;
    private Double averageRating;
    private String key;
    private Long popularity;

    public BookDTO() {
    }

    public BookDTO(String title, String author, String coverUrl, String openLibraryId,
                   String description, Double averageRating, String key, Long popularity) {
        this.title = title;
        this.author = author;
        this.coverUrl = coverUrl;
        this.openLibraryId = openLibraryId;
        this.description = description;
        this.averageRating = averageRating;
        this.key = key;
        this.popularity = popularity;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public String getOpenLibraryId() {
        return openLibraryId;
    }

    public String getDescription() {
        return description;
    }

    public Double getAverageRating() {
        return averageRating;
    }

    public String getKey() {
        return key;
    }

    public Long getPopularity() {
        return popularity;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public void setOpenLibraryId(String openLibraryId) {
        this.openLibraryId = openLibraryId;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setAverageRating(Double averageRating) {
        this.averageRating = averageRating;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setPopularity(Long popularity) {
        this.popularity = popularity;
    }
}
