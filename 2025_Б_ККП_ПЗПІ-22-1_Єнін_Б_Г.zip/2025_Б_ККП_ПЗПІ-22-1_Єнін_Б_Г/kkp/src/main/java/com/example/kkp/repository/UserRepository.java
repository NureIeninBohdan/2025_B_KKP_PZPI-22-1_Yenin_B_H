package com.example.kkp.repository;

import com.example.kkp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    List<User> findTop10ByUsernameContainingIgnoreCase(String query);
    Optional<User> findByResetToken(String resetToken);

}
