package com.example.kkp.service;

import com.example.kkp.dto.UserSettingsDTO;
import com.example.kkp.model.User;
import com.example.kkp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.Optional;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public boolean existsByUsername(String username) {
        return userRepository.findByUsername(username).isPresent();
    }

    public boolean existsByEmail(String email) {
        return userRepository.findByEmail(email).isPresent();
    }

    public User registerUser(String username, String email, String rawPassword) {
        if (existsByUsername(username) || existsByEmail(email)) {
            throw new IllegalArgumentException("Користувач з таким ім'ям або адресою вже існує");
        }

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPasswordHash(passwordEncoder.encode(rawPassword));

        ZonedDateTime kyivNow = ZonedDateTime.now(ZoneId.of("Europe/Kiev"));
        user.setCreatedAt(kyivNow);
        user.setRole("USER");

        return userRepository.save(user);
    }

    public Optional<User> authenticate(String usernameOrEmail, String rawPassword) {
        Optional<User> userOpt = userRepository.findByUsername(usernameOrEmail);
        if (userOpt.isEmpty()) {
            userOpt = userRepository.findByEmail(usernameOrEmail);
        }
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким ім'ям не знайдено"));
    }

    public User save(User user) {
        return userRepository.save(user);
    }

    public void updateUserSettings(Long userId, UserSettingsDTO dto) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("Користувача не знайдено"));

        if (dto.getUsername() != null && !dto.getUsername().equals(user.getUsername())) {
            Optional<User> byUsername = userRepository.findByUsername(dto.getUsername());
            if (byUsername.isPresent()) throw new IllegalArgumentException("Користувач з таким логіном вже існує");
            user.setUsername(dto.getUsername());
        }

        if (dto.getEmail() != null && !dto.getEmail().equals(user.getEmail())) {
            Optional<User> byEmail = userRepository.findByEmail(dto.getEmail());
            if (byEmail.isPresent()) throw new IllegalArgumentException("Користувач з таким email вже існує");
            user.setEmail(dto.getEmail());
        }

        if (dto.getNewPassword() != null && !dto.getNewPassword().isEmpty()) {
            user.setPasswordHash(passwordEncoder.encode(dto.getNewPassword()));
        }

        userRepository.save(user);
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Користувача не знайдено"));
    }

    public List<User> findByUsernameStartingWith(String query) {
        return userRepository.findTop10ByUsernameContainingIgnoreCase(query);
    }

    public String createPasswordResetToken(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Користувача з таким email не знайдено"));

        String token = UUID.randomUUID().toString();
        user.setResetToken(token);
        user.setResetTokenExpiry(LocalDateTime.now().plusHours(1));
        userRepository.save(user);

        return token;
    }

    public boolean isPasswordResetTokenValid(String token) {
        Optional<User> userOpt = userRepository.findByResetToken(token);
        return userOpt.isPresent() && userOpt.get().getResetTokenExpiry() != null &&
                LocalDateTime.now().isBefore(userOpt.get().getResetTokenExpiry());
    }

    public void updatePassword(String token, String newPassword) {
        Optional<User> userOpt = userRepository.findByResetToken(token);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPasswordHash(passwordEncoder.encode(newPassword));
            user.setResetToken(null);
            user.setResetTokenExpiry(null);
            userRepository.save(user);
        }
    }

    public Optional<User> findByResetToken(String token) {
        return userRepository.findByResetToken(token);
    }
}
