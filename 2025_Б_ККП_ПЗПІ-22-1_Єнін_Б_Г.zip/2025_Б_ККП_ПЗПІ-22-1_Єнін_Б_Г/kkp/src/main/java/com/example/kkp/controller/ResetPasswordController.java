package com.example.kkp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.kkp.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class ResetPasswordController {

    private static final Logger logger = LoggerFactory.getLogger(ResetPasswordController.class);

    @Autowired
    private UserService userService;

    @GetMapping("/reset-password")
    public String showResetForm(@RequestParam String token, Model model) {
        if (!userService.isPasswordResetTokenValid(token)) {
            model.addAttribute("errorMessage", "Невірний або прострочений токен.");
            return "reset-password";
        }
        model.addAttribute("token", token);
        return "reset-password";
    }

    @PostMapping("/reset-password")
    public String handleReset(@RequestParam String token,
                              @RequestParam String newPassword,
                              Model model) {
        if (!userService.isPasswordResetTokenValid(token)) {
            model.addAttribute("errorMessage", "Невірний або прострочений токен.");
            return "reset-password";
        }

        userService.updatePassword(token, newPassword);
        logger.info("Пароль успішно змінено для токена: {}", token);
        model.addAttribute("successMessage", "Пароль успішно змінено.");
        return "reset-password";
    }
}
