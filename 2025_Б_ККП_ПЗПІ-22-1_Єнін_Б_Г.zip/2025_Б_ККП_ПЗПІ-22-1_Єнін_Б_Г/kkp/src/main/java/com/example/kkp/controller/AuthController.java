    package com.example.kkp.controller;

    import com.example.kkp.model.User;
    import com.example.kkp.service.UserService;
    import jakarta.servlet.http.HttpSession;
    import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.stereotype.Controller;
    import org.springframework.ui.Model;
    import org.springframework.web.bind.annotation.*;
    import org.springframework.security.core.annotation.AuthenticationPrincipal;
    import com.example.kkp.service.CustomUserDetails;

    @Controller
    public class AuthController {

        @Autowired
        private UserService userService;


        @GetMapping("/login")
        public String showLoginForm(@RequestParam(value = "error", required = false) String error,
                                    Model model) {
            if (error != null) {
                model.addAttribute("errorMessage", "Невірне ім’я користувача або пароль");
            }
            return "loginpage";
        }

        @GetMapping("/register")
        public String showRegisterForm() {
            return "register";
        }


        @GetMapping("/logout")
        public String logout(HttpSession session) {
            session.invalidate();
            return "redirect:/login";
        }

        @PostMapping("/register")
        public String processRegistration(@RequestParam String username,
                                          @RequestParam String email,
                                          @RequestParam String password,
                                          Model model) {

            if (userService.existsByUsername(username) || userService.existsByEmail(email)) {
                model.addAttribute("errorMessage", "Користувач з таким ім'ям або адресою вже існує");
                return "register";
            }

            userService.registerUser(username, email, password);
            return "redirect:/login";
        }


    }
