package com.example.kkp.controller;

import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.error.ErrorAttributeOptions.Include;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.ServletWebRequest;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

@Controller
public class CustomErrorController implements ErrorController {

    private static final Logger log = LoggerFactory.getLogger(CustomErrorController.class);

    private final ErrorAttributes errorAttributes;

    public CustomErrorController(ErrorAttributes errorAttributes) {
        this.errorAttributes = errorAttributes;
    }

    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        ServletWebRequest webRequest = new ServletWebRequest(request);

        ErrorAttributeOptions options = ErrorAttributeOptions.of(Include.MESSAGE, Include.EXCEPTION);
        Map<String, Object> attrs = errorAttributes.getErrorAttributes(webRequest, options);

        log.debug("Error attributes: {}", attrs);

        Object statusObj = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Integer status = null;

        if (statusObj instanceof Integer) {
            status = (Integer) statusObj;
        } else if (statusObj instanceof String) {
            try {
                status = Integer.valueOf((String) statusObj);
            } catch (NumberFormatException e) {

            }
        }

        if (status == null) {
            Object s = attrs.get("status");
            if (s instanceof Integer) {
                status = (Integer) s;
            } else if (s instanceof Number) {
                status = ((Number) s).intValue();
            } else if (s instanceof String) {
                try {
                    status = Integer.valueOf((String) s);
                } catch (NumberFormatException ignored) { }
            }
        }

        if (status == null) {
            status = 500;
        }

        String error = (String) attrs.getOrDefault("error", "Помилка");
        String message = (String) attrs.getOrDefault("message", "");

        model.addAttribute("status", status);
        model.addAttribute("error", error);
        model.addAttribute("message", message);

        log.info("Rendering error page. status={}, error={}, message={}", status, error, message);

        return "error";
    }
}
