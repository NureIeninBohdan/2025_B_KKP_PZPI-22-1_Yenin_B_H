package com.example.kkp.controller;

import com.example.kkp.service.RatingService;
import com.example.kkp.service.ReadingStatusService;
import com.example.kkp.service.CustomUserDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/books")
public class BookInteractionController {

    private final RatingService ratingService;
    private final ReadingStatusService statusService;

    public BookInteractionController(RatingService ratingService, ReadingStatusService statusService) {
        this.ratingService = ratingService;
        this.statusService = statusService;
    }

    @PostMapping("/{bookId}/rating")
    public ResponseEntity<?> setRating(
            @PathVariable Long bookId,
            @RequestBody Map<String, Integer> body,
            @AuthenticationPrincipal CustomUserDetails user
    ) {
        if (user == null) return ResponseEntity.status(401).body("Not authenticated");
        Integer rating = body.get("rating");
        if (rating == null) {
            ratingService.removeUserRating(user.getId(), bookId);
        } else {
            ratingService.setUserRating(user.getId(), bookId, rating);
        }
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{bookId}/status")
    public ResponseEntity<?> setStatus(
            @PathVariable Long bookId,
            @RequestBody Map<String, String> body,
            @AuthenticationPrincipal CustomUserDetails user
    ) {
        if (user == null) return ResponseEntity.status(401).body("Not authenticated");
        String status = body.get("status");
        if (status == null || status.equals("Не вибрано")) {
            statusService.removeUserStatus(user.getId(), bookId);
        } else {
            statusService.setUserStatus(user.getId(), bookId, status);
        }
        return ResponseEntity.ok().build();
    }
}
