package com.example.kkp.controller;

import com.example.kkp.dto.UserSettingsDTO;
import com.example.kkp.model.User;
import com.example.kkp.service.UserService;
import com.example.kkp.service.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class SettingsController {

    @Autowired
    private UserService userService;

    @Autowired
    private UserDetailsService userDetailsService;

    @GetMapping("/settings")
    public String showSettingsPage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated() ||
                authentication.getPrincipal().equals("anonymousUser")) {
            return "redirect:/login";
        }

        String username = authentication.getName();
        User user = userService.findByUsername(username);

        UserSettingsDTO userSettingsDTO = new UserSettingsDTO();
        userSettingsDTO.setUsername(user.getUsername());
        userSettingsDTO.setEmail(user.getEmail());

        model.addAttribute("userSettingsDTO", userSettingsDTO);
        return "settings";
    }

    @PostMapping("/settings")
    public String updateSettings(UserSettingsDTO userSettingsDTO,
                                 RedirectAttributes redirectAttributes) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated() ||
                authentication.getPrincipal().equals("anonymousUser")) {
            return "redirect:/login";
        }

        Long userId = ((CustomUserDetails) authentication.getPrincipal()).getId();

        if (userSettingsDTO.getNewPassword() != null && !userSettingsDTO.getNewPassword().isEmpty()) {
            if (!userSettingsDTO.getNewPassword().equals(userSettingsDTO.getConfirmNewPassword())) {
                redirectAttributes.addFlashAttribute("errorMessage", "Нові паролі не збігаються");
                redirectAttributes.addFlashAttribute("userSettingsDTO", userSettingsDTO);
                return "redirect:/settings";
            }
        }

        try {
            userService.updateUserSettings(userId, userSettingsDTO);

            UserDetails userDetails = userDetailsService.loadUserByUsername(userSettingsDTO.getUsername());
            UsernamePasswordAuthenticationToken newAuth =
                    new UsernamePasswordAuthenticationToken(userDetails, userDetails.getPassword(), userDetails.getAuthorities());
            SecurityContextHolder.getContext().setAuthentication(newAuth);

            redirectAttributes.addFlashAttribute("successMessage", "Налаштування збережено");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }

        return "redirect:/settings";
    }
}
