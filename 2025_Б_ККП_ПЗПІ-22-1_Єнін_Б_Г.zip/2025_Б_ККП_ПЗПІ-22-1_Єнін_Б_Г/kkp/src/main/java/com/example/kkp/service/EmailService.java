package com.example.kkp.service;

import com.sendgrid.Method;
import com.sendgrid.Request;
import com.sendgrid.Response;
import com.sendgrid.SendGrid;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);
    private final SendGrid sendGrid;
    private final String fromEmail;

    @Autowired
    public EmailService(SendGrid sendGrid, @Value("${sendgrid.from-email:bohdan.ienin@nure.ua}") String fromEmail) {
        this.sendGrid = sendGrid;
        this.fromEmail = fromEmail;
    }

    public boolean sendEmail(String to, String subject, String contentText) {
        logger.info("Sending email to {}", to);

        if (sendGrid == null) {
            logger.error("SendGrid instance is NULL, cannot send email.");
            return false;
        }

        Email from = new Email(fromEmail);
        Email toEmail = new Email(to);
        Content content = new Content("text/plain", contentText);
        Mail mail = new Mail(from, subject, toEmail, content);

        Request request = new Request();
        try {
            request.setMethod(Method.POST);
            request.setEndpoint("mail/send");
            request.setBody(mail.build());
            Response response = sendGrid.api(request);

            int status = response.getStatusCode();
            logger.info("SendGrid response status: {}", status);
            logger.info("SendGrid response body: {}", response.getBody());
            logger.debug("SendGrid response headers: {}", response.getHeaders());

            if (status >= 200 && status < 300) {
                logger.info("Email successfully sent to {}", to);
                return true;
            } else {
                logger.error("Failed to send email to {}. Status: {}, Body: {}", to, status, response.getBody());
                return false;
            }
        } catch (IOException ex) {
            logger.error("Exception occurred while sending email to {}", to, ex);
            return false;
        }
    }
}
