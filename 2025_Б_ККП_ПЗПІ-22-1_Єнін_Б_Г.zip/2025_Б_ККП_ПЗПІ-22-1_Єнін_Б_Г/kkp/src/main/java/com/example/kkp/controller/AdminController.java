package com.example.kkp.controller;

import com.example.kkp.model.Book;
import com.example.kkp.dto.BookDTO;
import com.example.kkp.repository.BookRepository;
import com.example.kkp.service.BookImportService;
import com.example.kkp.service.BookDeleteService;
import com.example.kkp.service.CustomUserDetails;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasAuthority('ADMIN')")
public class AdminController {

    private final BookImportService bookImportService;
    private final BookDeleteService bookDeleteService;
    private final BookRepository bookRepository;

    private final String COVER_UPLOAD_DIR = "uploads/covers";
    private final String NO_COVER_FILENAME = "No Cover.jpg";
    private final String NO_COVER_PATH = "/uploads/covers/" + NO_COVER_FILENAME;

    public AdminController(BookImportService bookImportService,
                           BookDeleteService bookDeleteService,
                           BookRepository bookRepository) {
        this.bookImportService = bookImportService;
        this.bookDeleteService = bookDeleteService;
        this.bookRepository = bookRepository;
    }

    @GetMapping("/search-books")
    public ResponseEntity<List<BookDTO>> searchBooks(@RequestParam String query) {
        List<BookDTO> books = bookImportService.searchBooks(query);
        return ResponseEntity.ok(books);
    }

    @PostMapping("/import-book")
    public ResponseEntity<String> importBook(@RequestBody Map<String, String> body,
                                             @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Користувач не авторизований");
        }
        String openLibraryId = body.get("openLibraryId");
        if (openLibraryId == null || openLibraryId.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Невірний ID книги");
        }
        try {
            bookImportService.importBookByOpenLibraryId(openLibraryId.trim());
            return ResponseEntity.ok("Книга імпортована успішно");
        } catch (RuntimeException e) {
            if ("Книга вже існує".equals(e.getMessage())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
            }
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Помилка при імпорті: " + e.getMessage());
        }
    }



    @PostMapping("/delete-book")
    public ResponseEntity<String> deleteBook(@RequestBody Map<String, String> body,
                                             @AuthenticationPrincipal UserDetails userDetails) {
        if (userDetails == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Користувач не авторизований");
        }
        String bookIdStr = body.get("bookId");
        if (bookIdStr == null || bookIdStr.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("Невірний ID книги");
        }
        try {
            Long bookId = Long.parseLong(bookIdStr.trim());
            bookDeleteService.deleteBookById(bookId);
            return ResponseEntity.ok("Книгу успішно видалено");
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body("Невірний формат ID книги");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Помилка при видаленні: " + e.getMessage());
        }
    }

    @GetMapping("/books/{id}/edit")
    public String showEditBookForm(@PathVariable Long id,
                                   @AuthenticationPrincipal CustomUserDetails currentUser,
                                   Model model) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        if (book.getCoverUrl() == null || book.getCoverUrl().isEmpty()) {
            book.setCoverUrl(NO_COVER_PATH);
        }

        model.addAttribute("book", book);
        model.addAttribute("isAuthenticated", currentUser != null);

        return "book-edit";
    }


    @PostMapping("/books/{id}/edit")
    public String saveBookEdits(@PathVariable Long id,
                                @RequestParam String title,
                                @RequestParam String author,
                                @RequestParam String description,
                                @RequestParam(required = false) MultipartFile coverFile,
                                @RequestParam(required = false) String deleteCover) throws IOException {

        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Книга не знайдена"));

        book.setTitle(title);
        book.setAuthor(author);
        book.setDescription(description);

        Path uploadDir = Paths.get(COVER_UPLOAD_DIR);
        if (!Files.exists(uploadDir)) {
            Files.createDirectories(uploadDir);
        }

        if ("true".equals(deleteCover)) {
            deleteOldCoverFile(book.getCoverUrl());
            book.setCoverUrl(NO_COVER_PATH);
        } else if (coverFile != null && !coverFile.isEmpty()) {
            deleteOldCoverFile(book.getCoverUrl());

            String originalFilename = StringUtils.cleanPath(coverFile.getOriginalFilename());

            if (NO_COVER_FILENAME.equalsIgnoreCase(originalFilename)) {
                String extension = "";
                int dotIdx = originalFilename.lastIndexOf('.');
                if (dotIdx > 0) extension = originalFilename.substring(dotIdx);
                originalFilename = "cover_" + id + "_" + System.currentTimeMillis() + extension;
            }

            String fileName = UUID.randomUUID() + "_" + originalFilename;
            Path filePath = uploadDir.resolve(fileName);

            Files.copy(coverFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            book.setCoverUrl("/uploads/covers/" + fileName);
        } else if (book.getCoverUrl() == null || book.getCoverUrl().isEmpty()) {
            book.setCoverUrl(NO_COVER_PATH);
        }

        bookRepository.save(book);

        return "redirect:/books/" + id;
    }

    private void deleteOldCoverFile(String coverUrl) throws IOException {
        if (coverUrl != null && !coverUrl.isEmpty() && !coverUrl.endsWith(NO_COVER_FILENAME)) {
            String filename = Paths.get(coverUrl).getFileName().toString();
            Path filePath = Paths.get(COVER_UPLOAD_DIR).resolve(filename);
            if (Files.exists(filePath)) {
                Files.delete(filePath);
            }
        }
    }
}
