package com.example.kkp.controller;

import com.example.kkp.model.User;
import com.example.kkp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/profiles")
public class ProfileSearchController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/search")
    public List<User> searchProfiles(@RequestParam("q") String query) {
        return userRepository.findTop10ByUsernameContainingIgnoreCase(query);
    }
}